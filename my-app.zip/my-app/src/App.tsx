import Button from "./components/Button/Button"
//quando exporta DEFAULT
import { IconButton, IconButton2 } from "./components/IconButton/IconButton"
//quando exporta com const

import Ronaldinho from './assets/jorge.jpg'
function App() {
  const appName = "Meu app"
  const user = {
    name: 'É o bruxo',
    image: Ronaldinho
  }
  const products = [
    {id: 8, name:"Banana", value:10},
    {id: 9, name:"Mamão", value: 12},
    {id: 10, name:"Maçã", value: 8}
  ]
  return (
    <> {/* fragment */}
    <h1>{appName}</h1>
    <img src={user.image} alt={user.name} />
    <p>{user.name}</p>
      <Button/>
      <IconButton/>
      <IconButton2/>
      <ul>
      {products.map(product =>(
        <li key={product.id}>{product.name} {product.value}</li>
      ))}
    </ul>
    </>
    
  )
  }

export default App
