
function Button () {
    return <button>Salvar</button>
}

export default Button