export const IconButton = () => {
    return (<button>Icone</button>)
}

export const IconButton2 = () => {
    return (<button>Icone</button>)
}